import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class MainWindow extends JFrame{
    JTabbedPane mainPane;
    JPanel panelTask1;
    MyPanel panelTask2;
    JPanel panelTask3;
    ButtonGroup radioButtonGroup;
    JRadioButton[] radioButtons;
    ImageIcon[] icons;
    JList leftList, rightList;
    DefaultListModel leftListModel, rightListModel;
    JButton moveToLeftList, moveToRightList;
    public final static Dimension SIZE = new Dimension(800, 500);
    public final static Dimension LIST_SIZE = new Dimension(300, 500);
    public final static int NUM = 3;

    MainWindow(){

        super("Lab12");
        mainPane = new JTabbedPane();
        panelTask1 = new JPanel();
        JPanel panelButtons = new JPanel(new BorderLayout());
        leftList = new JList();
        rightList = new JList();
        leftListModel = new DefaultListModel();
        rightListModel = new DefaultListModel();
        radioButtonGroup = new ButtonGroup();
        moveToLeftList = new JButton("<<<");
        moveToRightList = new JButton(">>>");
        panelTask2 = new MyPanel();
        panelTask3 = new JPanel();

        panelTask1.setLayout(new BorderLayout());
        panelTask1.add(leftList, BorderLayout.WEST);
        panelTask1.add(rightList, BorderLayout.EAST);
        panelButtons.add(moveToLeftList, BorderLayout.SOUTH);
        panelButtons.add(moveToRightList, BorderLayout.NORTH);
        panelTask1.add(panelButtons, BorderLayout.CENTER);
        panelTask1.setPreferredSize(SIZE);
        leftList.setPreferredSize(LIST_SIZE);
        rightList.setPreferredSize(LIST_SIZE);

        leftListModel.addElement(123);
        leftListModel.addElement("Hello, Vadim Yur'evich!");
        leftListModel.addElement("HHAHAHAHAAHHAHAHHAHAHA");
        leftListModel.addElement("¯\\_(ツ)_/¯");
        leftListModel.addElement(":;(∩´﹏`∩);:");
        leftListModel.addElement(666.666);
        rightListModel.addElement("Hello");
        rightListModel.addElement(123456789);

        updateModels();

        mainPane.add(panelTask1, "Task 1");
        mainPane.add(panelTask2, "Task 2");
        mainPane.add(panelTask3, "Task 3");
        add(mainPane);

        moveToLeftList.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e){
                int[] temp = rightList.getSelectedIndices();

                if (temp.length == 0){
                    for (Object item : rightListModel.toArray()){
                        leftListModel.addElement(item);
                    }
                    rightListModel.clear();
                } else if (temp.length != 0){
                    int i = 0;
                    for (int index : temp){
                        leftListModel.addElement(rightListModel.get(index - i));
                        rightListModel.removeElementAt(index - i);
                        i++;
                    }

                }

                //updateModels();
            }
        });

        moveToRightList.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e){
                int[] temp = leftList.getSelectedIndices();
                if (temp.length == 0){
                    for (Object item : leftListModel.toArray()){
                        rightListModel.addElement(item);
                    }
                    leftListModel.clear();
                } else if (temp.length != 0){
                    int i = 0;
                    for (int index : temp){
                        rightListModel.addElement(leftListModel.get(index - i));
                        leftListModel.removeElementAt(index - i);
                        i++;
                    }
                }
                //updateModels();
            }
        });

        icons = new ImageIcon[NUM + 1];
        for (int i = 0 ; i < NUM + 1 ; i++){
            String path = "src//icon" + (i + 5)+".png";
            icons[i] = new ImageIcon(path);
        }

        radioButtons = new JRadioButton[NUM];
        for (int i = 0 ; i < NUM ; i++){
            radioButtons[i] = new JRadioButton("Test label!");
            radioButtons[i].setFont(new Font("Dialog", Font.ITALIC, 24));
            radioButtons[i].setIcon(icons[0]);
            radioButtons[i].setSelectedIcon(icons[1]);
            radioButtons[i].setPressedIcon(icons[2]);
            radioButtons[i].setRolloverIcon(icons[3]);
            radioButtonGroup.add(radioButtons[i]);
            panelTask3.add(radioButtons[i]);
        }

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e){
                onClose();
            }
        });
    }

    private void onClose(){
        dispose();
    }

    private void updateModels(){
        leftList.setModel(leftListModel);
        rightList.setModel(rightListModel);
    }
}
