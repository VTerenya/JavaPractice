public class Main {

    public static void main(String[] args) {
        MainWindow window = new MainWindow();
        window.pack();
        window.setVisible(true);
    }
}
