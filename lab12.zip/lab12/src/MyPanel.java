import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MyPanel extends JPanel implements MouseListener{

    final static Color color = Color.red;
    private String oldText;

    public MyPanel(){
        setLayout(new GridLayout(10, 10));
        setPreferredSize(MainWindow.SIZE);
        for (int i = 0 ; i < 100 ; i++){
            oldText = "Button " + i + 1;
            JButton button = new JButton(oldText);
            button.addMouseListener(this);
            button.setBackground(color);
            add(button);
        }
         oldText = "";
    }
    public void mouseEntered(MouseEvent e){
        JButton tempButton;
        tempButton = (JButton) e.getSource();
        tempButton.setBackground(Color.blue);
    }
    public void mouseExited(MouseEvent e)
    {
        JButton tempButton;
        tempButton = (JButton) e.getSource();
        tempButton.setBackground(color);
    }
    public void mousePressed(MouseEvent e)
    {
        JButton tempButton;
        tempButton = (JButton) e.getSource();
        oldText = tempButton.getText();
        tempButton.setText("Clicked!");
    }
    public void mouseReleased(MouseEvent e)
    {
        JButton tempButton;
        tempButton = (JButton) e.getSource();
        tempButton.setText(oldText);

    }
    public void mouseClicked(MouseEvent e)
    {

    }

}
