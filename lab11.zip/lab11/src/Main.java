public class Main {

    public static void main(String[] args) {
	MainWindow paint = new MainWindow();
	paint.pack();
	paint.setVisible(true);
	}
}
